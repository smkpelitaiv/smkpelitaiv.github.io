---
title: "Hasil SIMULASI UNBK 1"
date: 2019-11-17T17:58:07+07:00
draft: false
---

Kepada:

Seluruh Peserta Didik Kelas XII

Melalui website ini kami informasikan hasil SIMULASI UNBK 1 Mata pelajaran Bahasa Inggris dan Matematika yang telah dilaksanakan pada tanggal 13 – 14 Nopember 2019 dengan hasil skor sebagai berikut:

# BAHASA INGGRIS
![Hasil Simulasi UNBK 1 Bahasa Inggris](/images/simulasiunbk1bahasainggris/0001.jpg)
![Hasil Simulasi UNBK 1 Bahasa Inggris](/images/simulasiunbk1bahasainggris/0002.jpg)
![Hasil Simulasi UNBK 1 Bahasa Inggris](/images/simulasiunbk1bahasainggris/0003.jpg)
![Hasil Simulasi UNBK 1 Bahasa Inggris](/images/simulasiunbk1bahasainggris/0004.jpg)
![Hasil Simulasi UNBK 1 Bahasa Inggris](/images/simulasiunbk1bahasainggris/0005.jpg)
![Hasil Simulasi UNBK 1 Bahasa Inggris](/images/simulasiunbk1bahasainggris/0006.jpg)
![Hasil Simulasi UNBK 1 Bahasa Inggris](/images/simulasiunbk1bahasainggris/0007.jpg)
![Hasil Simulasi UNBK 1 Bahasa Inggris](/images/simulasiunbk1bahasainggris/0008.jpg)

# MATEMATIKA
![Hasil Simulasi UNBK 1 Matematika](/images/simulasiunbk1matematika/0001.jpg)
![Hasil Simulasi UNBK 1 Matematika](/images/simulasiunbk1matematika/0002.jpg)
![Hasil Simulasi UNBK 1 Matematika](/images/simulasiunbk1matematika/0003.jpg)
![Hasil Simulasi UNBK 1 Matematika](/images/simulasiunbk1matematika/0004.jpg)
![Hasil Simulasi UNBK 1 Matematika](/images/simulasiunbk1matematika/0005.jpg)
![Hasil Simulasi UNBK 1 Matematika](/images/simulasiunbk1matematika/0006.jpg)
![Hasil Simulasi UNBK 1 Matematika](/images/simulasiunbk1matematika/0007.jpg)

# Catatan:
1. Total Skor = Jumlah Soal Benar
2. Jumlah Soal Bahasa Inggris 50
3. Jumlah Soal Matematika 40
4. Hasil Essay = 0 dikarenakan Essay hanya test Simulasi Sistem Penilaian Non Obyektif